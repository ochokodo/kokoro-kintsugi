const CACHE_NAME = 'kokoro-kintsugi-v1';
const urlsToCache = [
  '/kokoro-kintsugi/',
  '/kokoro-kintsugi/index.html'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});
